﻿namespace Application.DTOs
{
    public class TokenData
    {
        public required string Identifier { get; set; }
    }
}
