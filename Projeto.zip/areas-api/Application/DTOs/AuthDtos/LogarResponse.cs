﻿namespace Application.DTOs.Auth
{
    public class LogarResponse
    {
        public required string Token { get; set; }
    }
}
