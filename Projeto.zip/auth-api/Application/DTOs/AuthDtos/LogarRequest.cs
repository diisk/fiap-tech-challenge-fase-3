﻿namespace Application.DTOs.Auth
{
    public class LogarRequest
    {
        public required string Login { get; set; }
        public required string Senha { get; set; }
    }
}