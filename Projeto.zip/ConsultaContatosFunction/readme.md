# RabbitMQTrigger - C<span>#</span>

The `RabbitMQTrigger` makes it incredibly easy to react to new events from a RabbitMQ queue. This sample demonstrates a simple use case of processing data from a given RabbitMQ Queue using C#.

## How it works

For a `RabbitMQTrigger` to work, you must provide a queue name which dictates where the queue messages should be read from.