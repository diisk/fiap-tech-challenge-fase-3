﻿
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using RabbitMQ.Client;
using System.Text;
using System.Text.Json;

namespace ConsultaContatosFunction
{
    public class LerConsultaContatoDlqFunction
    {
        private readonly ILogger _logger;
        private readonly ConnectionFactory _factory;

        private const string QUEUE_NAME = "consulta-contato-dlq";

        public LerConsultaContatoDlqFunction(ILoggerFactory loggerFactory)
        {
            _logger = loggerFactory.CreateLogger<LerConsultaContatoDlqFunction>();

            var hostname = Environment.GetEnvironmentVariable("RABBITMQ_HOST") ?? "rabbitmq";
            _logger.LogInformation($"[DEBUG] RABBITMQ_HOST = {hostname}");

            _factory = new ConnectionFactory
            {
                HostName = hostname,
                Port = 5672,
                UserName = "guest",
                Password = "guest",
            };
        }

        [Function("LerConsultaContatoDlqFunction")]
        public async Task Run([TimerTrigger("*/30 * * * * *")] TimerInfo myTimer)
        {
            _logger.LogInformation($">>> Azure Function disparada em: {DateTime.UtcNow}");

            try
            {
                _logger.LogInformation("🪝 Aguardando subida do RabbitMQ...");
                await Task.Delay(5000);

                _logger.LogInformation("🔌 Tentando criar conexão com RabbitMQ...");
                await using var connection = await _factory.CreateConnectionAsync();
                _logger.LogInformation("✅ Conexão criada com sucesso.");

                _logger.LogInformation("📡 Criando canal...");
                var channel = await connection.CreateChannelAsync();
                _logger.LogInformation("✅ Canal criado com sucesso.");

                _logger.LogInformation($"📦 Lendo mensagem da fila '{QUEUE_NAME}'...");
                var result = await channel.BasicGetAsync(QUEUE_NAME, autoAck: true);

                if (result == null)
                {
                    _logger.LogInformation("📭 Nenhuma mensagem encontrada na DLQ.");
                    return;
                }

                var body = result.Body.ToArray();
                var mensagem = Encoding.UTF8.GetString(body);
                _logger.LogInformation("📩 Mensagem recebida:");
                _logger.LogInformation(mensagem);
            }
            catch (Exception ex)
            {
                _logger.LogError($"❌ Falha ao conectar no RabbitMQ: {ex.Message}");
                _logger.LogError($"🔎 StackTrace: {ex.StackTrace}");
            }
        }
    }
}
