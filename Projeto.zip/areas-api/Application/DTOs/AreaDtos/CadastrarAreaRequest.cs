﻿namespace Application.DTOs.AreaDtos
{
    public class CadastrarAreaRequest
    {
        public required List<NovaAreaRequest> Areas { get; set; }
    }
}
