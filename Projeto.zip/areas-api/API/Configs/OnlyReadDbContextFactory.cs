﻿namespace Infrastructure.DbContexts
{
    public class OnlyReadDbContextFactory : BaseDbContextFactory<OnlyReadDbContext> { }
}
