﻿using System.ComponentModel;

namespace Domain.Enums.AreaEnums
{
    public enum RegiaoBrasil
    {
        [Description("Norte")]
        NORTE,
        [Description("Nordeste")]
        NORDESTE,
        [Description("Centro Oeste")]
        CENTRO_OESTE,
        [Description("Sudeste")]
        SUDESTE,
        [Description("Sul")]
        SUL,
        


    }
}
