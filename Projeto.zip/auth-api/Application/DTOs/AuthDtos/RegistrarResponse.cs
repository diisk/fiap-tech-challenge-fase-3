﻿namespace Application.DTOs.AuthDtos
{
    public class RegistrarResponse
    {
        public int Id { get; set; }
    }
}
